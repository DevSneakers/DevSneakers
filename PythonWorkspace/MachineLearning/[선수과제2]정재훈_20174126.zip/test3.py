# 3. 양수만 출력
# numbers 라는 리스트가 주어졌을 때, 양수만 출력하는 프로그램을 작성하세요.
numbers = [1, -2, 3, -7, 8, -6, 11, 0]
i = 0
n = 0

for n in numbers:
    i = i + 1
    if n > 0:
        print(n)
