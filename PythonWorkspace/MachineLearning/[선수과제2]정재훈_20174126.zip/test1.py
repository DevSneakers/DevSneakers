# 1. 2 - 9 사이의 자연수(N)를 입력 받아서 구구단을 출력하는 프로그램을 구현하세요.
n = int(input("GuGu-Table : "))
i = 0
result = 0

for i in range(9):
    i = i + 1
    result = n * i
    print("%d X %d = %d" % (n, i, result))
