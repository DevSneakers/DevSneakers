# 4. 거꾸로 문자열
# 사용자로부터 문자열 sports를 입력 받아 거꾸로 출력

String = input("문자열 입력 : ")
n = 1
for i in String:
    print(String[-n])
    n = n + 1