# 5. 리스트 지우기
List = ['hologram', 'charming', 'approve']
while 1:
    if List == []:
        break
    print(List)
    delete = input("입력한 문자열이 포함된 단어가 List에서 삭제됩니다. : ")
    for l in List:
        if delete in l:
            List.remove(l)