# 2. 주민번호를 입력 받아서 마지막 6자리를 *로 출력하는 프로그램을 작성하세요.
id_num = input("주민번호를 입력하세요(중간에 -를 입력하세요.) : ")
id_num.strip()
front = id_num[:8]
secure = "*" * 6

print("%s%s" % (front, secure))